// 자바스크립트 함수 인자 특성
function log() {}

log(10, 20, 30);
