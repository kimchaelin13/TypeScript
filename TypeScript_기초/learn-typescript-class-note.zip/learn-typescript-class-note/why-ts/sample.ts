function add(a: number, b: number): number {
  return a + b;
}
var result = add(10, 20);
// result.toLocaleString();
result.toLocaleString();

// add(10, '20');
