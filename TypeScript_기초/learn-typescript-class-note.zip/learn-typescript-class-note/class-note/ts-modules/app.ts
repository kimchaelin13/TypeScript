import { Todo } from './types'

var item: Todo = {
  title: '할 일 1',
  checked: false,
}