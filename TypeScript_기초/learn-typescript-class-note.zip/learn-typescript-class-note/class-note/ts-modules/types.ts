export interface Todo {
  title: string;
  checked: boolean;
}
