function sum(a, b) {
  return a + b;
}

sum(10, 20, 30, 40, 50);