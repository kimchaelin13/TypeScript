function sum(a: number, b: number): number {
  return a + b;
}

sum(10, 20);
