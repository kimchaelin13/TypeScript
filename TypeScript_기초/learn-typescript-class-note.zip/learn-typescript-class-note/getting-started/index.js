function sum(a, b) {
    return a + b;
}
sum(10, 20);
